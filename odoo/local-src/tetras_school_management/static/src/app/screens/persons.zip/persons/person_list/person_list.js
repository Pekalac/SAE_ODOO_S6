/** @odoo-module */

import { Component } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useTetras } from "@tetras_school_management/app/store/tetras_hook";
import { PersonLine } from "@tetras_school_management/app/screens/persons/person_list/person_line/person_line";
export class PersonListScreen extends Component {
    static template = "tetras_school_management.PersonListScreen";
    static components = { PersonLine };


    setup() {
        this.tetras = useTetras();
    }

    async onPersonClick(person) {
        this.tetras.showScreen("PersonFormScreen", {"person": person})
    }
}

registry.category("tetras_screens").add("PersonListScreen", PersonListScreen);
