/** @odoo-module */

import { Component } from "@odoo/owl";


export class PersonLine extends Component {
    static template = "tetras_school_management.PersonLine";

    static props = {
        name: String,
        personId: Number,
        onClick: { type: Function, optional: true },
    };
}

